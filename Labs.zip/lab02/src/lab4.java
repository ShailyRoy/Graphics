
import java.util.Random;

import javax.media.opengl.GL2;
import javax.media.opengl.GLAutoDrawable;
import javax.media.opengl.GLCapabilities;
import javax.media.opengl.GLEventListener;
import javax.media.opengl.GLProfile;
import javax.media.opengl.awt.GLCanvas;
import javax.swing.JFrame;

public class lab4 implements GLEventListener{
	
	static GLProfile profile = GLProfile.get(GLProfile.GL2);
    static GLCapabilities capabilities = new GLCapabilities(profile);
    // The canvas 
    static GLCanvas glcanvas = new GLCanvas(capabilities);
    
   public static void main(String[] args) {
	      //getting the capabilities object of GL2 profile
	   	  
	      
	      lab4 l = new lab4();
	      //creating frame
	      glcanvas.addGLEventListener(l);
	      glcanvas.setSize(600, 400);
	      
	      final JFrame frame = new JFrame ("straight Line");
	      //adding canvas to frame
	      frame.getContentPane().add(glcanvas);
	      frame.setSize(frame.getContentPane().getPreferredSize());
	      frame.setVisible(true);
	      
	   }
   public void display(GLAutoDrawable drawable) {
      final GL2 gl = drawable.getGL().getGL2();
       	  gl.glBegin (GL2.GL_POINTS);//static field
       	  Random r =new Random();
       		  float x0=-1+r.nextFloat()*(1-(-1));
       		  float x1=-1+r.nextFloat()*(1-(-1));
       		  float y0=-1+r.nextFloat()*(1-(-1));
       		float y1=-1+r.nextFloat()*(1-(-1));
       	  float dy=y1-y0;
       	  float dx=x1-x0;
       	  float dx1,dy1;
       	  int zone = -1;
       	  if(dx<0) {  //mod
       		  dx1=dx*(-1);
       	  }else {
       		  dx1=dx;
       	  }
       	  
       	  if(dy<0) {
       		  dy1=dy*(-1);
       	  }else {
       		  dy1=dy;
       	  }
       	  
       	  if(dx1>dy1) {  //zone detection
       		  if(dx>0 && dy>0) {
       			 zone=0; 
       		  }
       		  else if(dy>0 && dx<0) {
       			  zone=3;
       		  }
       		  else if(dy<0 && dx<0) {
       			  zone=4;
       		  }else if(dy<0 && dx>0){
       			  zone=7;
       		  }
       	  }else {
       		if(dx>0 && dy>0) {
      			 zone=1; 
      		  }
      		  else if(dy>0 && dx<0) {
      			  zone=2;
      		  }
      		  else if(dy<0 && dx<0) {
      			  zone=5;
      		  }else {
      			  zone=6;
      		  }
       	  }
       	  
       	  if(zone==1) {  //map to zone 0
       		  
     		float  temp=x0;
     		  x0=y0;
     		  y0=temp;
     		 temp=x1;
    		  x1=y1;
    		  y1=temp;
       	  } else if(zone==2) {
       	
   		  float temp=x0;
   		  x0=y0*(-1);
   		  y0=temp;
   		 temp=x1;
  		  x1=y1*(-1);
  		  y1=temp;
       	  } else if (zone==3) {
       		  x0=x0*(-1);
       		  x1=x1*(-1);
       	  }
       	  else if (zone==4) {
       		  x0=x0*(-1);
       		  x1=x1*(-1);
       		  y0=y0*(-1);
       		  y1=y1*(-1);
       	  }
       	  else if(zone==5) {
       		
   		 float temp=x0;
   		  x0=y0*(-1);
   		  y0=temp*(-1);
   		 temp=x1;
  		  x1=y1*(-1);
  		  y1=temp*(-1);
       	  }
       	  else if(zone==6) {
       		float temp=x0;
 		  x0=y0;
 		  y0=temp*(-1);
 		 temp=x1;
		  x1=y1;
		  y1=temp*(-1);
     	  } else if(zone==7) {
     		  y0=y0*(-1);
     		  y1=y1*(-1);
     	  }else {}
       	  
       	  if(x0>x1) {
       		  float tmp=x1;
       		  x1=x0;
       		  x0=tmp;
       	  }
       	  if(y0>y1) {
       		  float tmp=y0;
       		  y0=y1;
       		  y1=tmp;
       	  }
          dx=x1-x0;
          dy=y1-y0;
       	  float d=2*dy-dx;
       	  float inE=2*dy;
       	  float inNE=2*(dy-dx);
       	  float x=x0;
       	  float y=y0;
       	  System.out.println("ZONE = "+zone);
       	  while(x<x1) {
       		  if(d<0) {
       			  d=d+inE;
       		  }else {
       			  d=d+inNE;
       			  y=y+0.01f;
       		  }
       		  x=x+0.01f;
       		  if(zone==0) {
       			gl.glColor3f(1f,0f,0f);   //zone coloring
       			gl.glVertex2d(x,y);       //zone 0 Red
       		  } else if (zone==7) {
       			gl.glColor3f(0f,1f,0f);   
       			gl.glVertex2d(x,-y);   
       		  }
       		else if (zone==6) {
       			gl.glColor3f(0f,0f,1f);
       			gl.glVertex2d(y,-x);   
       		  }
       		else if (zone==5) {
       			gl.glColor3f(0.5f,0.5f,0.5f);   
       			gl.glVertex2d(-y,-x);   
       		  }
       		else if (zone==4) {
       			gl.glColor3f(1f,1f,0f);   
       			gl.glVertex2d(-x,-y);   
       		  }
       		else if (zone==3) {
       			gl.glColor3f(1f,1f,1f); 
       			gl.glVertex2d(-x,y);   
       		  }
       		else if (zone==2) {
       			gl.glColor3f(1f,0f,1f); 
       			gl.glVertex2d(-y,x);   
       		  }
       		else if (zone==1) {
       			gl.glColor3f(0f,1f,1f);
       			gl.glVertex2d(y,x);   
       		  }
       	  }
   
          gl.glEnd();
          
      
   }
   
   public void dispose(GLAutoDrawable arg0) {
      //method body
   }

   
   public void init(GLAutoDrawable drawable) {
      // method body
	   //4. drive the display() in a loop
	    }
   
   public void reshape(GLAutoDrawable arg0, int arg1, int arg2, int arg3, int arg4) {
      // method body
   }
   //end of main
}//end of classimport javax.media.opengl.GL2;