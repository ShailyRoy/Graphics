

import java.util.Random;

import javax.media.opengl.GL2;
import javax.media.opengl.GLAutoDrawable;
import javax.media.opengl.GLCapabilities;
import javax.media.opengl.GLEventListener;
import javax.media.opengl.GLProfile;
import javax.media.opengl.awt.GLCanvas;
import javax.swing.JFrame;

public class lab5_task2 implements GLEventListener{
	
	static GLProfile profile = GLProfile.get(GLProfile.GL2);
    static GLCapabilities capabilities = new GLCapabilities(profile);
    // The canvas 
    static GLCanvas glcanvas = new GLCanvas(capabilities);
    
    double xmin=-.5;
 	  double ymin=-.5;
 	  double xmax=.5;
 	  double ymax=.5;
    
   public static void main(String[] args) {
	      //getting the capabilities object of GL2 profile
	   	  
	      lab5_task2 l = new lab5_task2();
	      //creating frame
	      glcanvas.addGLEventListener(l);
	      glcanvas.setSize(600, 400);
	      
	      final JFrame frame = new JFrame ("straight Line");
	      //adding canvas to frame
	      frame.getContentPane().add(glcanvas);
	      frame.setSize(frame.getContentPane().getPreferredSize());
	      frame.setVisible(true);
	      
	   }
   
   public void display(GLAutoDrawable drawable) {
      final GL2 gl = drawable.getGL().getGL2();
       	  gl.glBegin (GL2.GL_LINES);//static field
       	  float x0,y0,x1,y1;
       	gl.glVertex2d(-.5,-.5);  //draw window
        gl.glVertex2d(.5,-.5);
        gl.glVertex2d(-.5,.5);
        gl.glVertex2d(.5,.5);
        
        gl.glVertex2d(-.5,.5);
        gl.glVertex2d(-.5,-.5);
        gl.glVertex2d(.5,.5);
        gl.glVertex2d(.5,-.5);
        
        for(int i=0; i<1000; i++) {
       	Random r = new Random();
       	float Low = -1.0f;
       	float High = 1.0f;
       		x0 = r.nextFloat()*(High-Low) + (Low);
       		y0 = r.nextFloat()*(High-Low) + (Low);
       		x1 = r.nextFloat()*(High-Low) + (Low);
       		y1 = r.nextFloat()*(High-Low) + (Low);
       		
       		int outcode0=computeOutcode(x0, y0);
       		int outcode1=computeOutcode(x1, y1);
       		System.out.println(outcode0 + " , " + outcode1);
       		
       		int d = outcode0 & outcode1;
       		if(d!=0) {
       			gl.glColor3f(1f,0f,0f);
       			gl.glVertex2d(x0,y0);
	       		gl.glVertex2d(x1,y1);
       		} 
       		else if(outcode0==0 && outcode1==0) {
       			gl.glColor3f(0f,1f,0f);
       			gl.glVertex2d(x0,y0);
	       		gl.glVertex2d(x1,y1);
       		}
       		else {
           	gl.glColor3f(0f,0f,1f);
   			gl.glVertex2d(x0,y0);
       		gl.glVertex2d(x1,y1);
       		double x,y,m,xx,yy;
       		m=(y1-y0)/(x1-x0);
       		if(x0>xmax) {
       			x=xmax;
       			y=y0+m*(xmax-x0);
       		}else if(x0<xmin) {
       			x=xmin;
       			y=y0+m*(xmin-x0);
       		}else if(y0>ymax) {
       			y=ymax;
       			x=x0+(1/m)*(ymax-y0);
       		}else if(y0<ymin){
       			y=ymin;
       			x=x0+(1/m)*(ymin-y0);
       		}else {
       			x=x0;
       			y=y0;
       		}
       		
       		if(x1>xmax) {
       			xx=xmax;
       			yy=y1+m*(xmax-x1);
       		}else if(x1<xmin) {
       			xx=xmin;
       			yy=y1+m*(xmin-x1);
       		}else if(y1>ymax) {
       			yy=ymax;
       			xx=x1+(1/m)*(ymax-y1);
       		}else if(y1<ymin){
       			yy=ymin;
       			xx=x1+(1/m)*(ymin-y1);
       		}else {
       			xx=x1;
       			yy=y1;
       		}
       		gl.glColor3f(0f,1f,0f);
   			gl.glVertex2d(x,y);
       		gl.glVertex2d(xx,yy);
           	  
       		}
          
        }
        gl.glEnd();
   }
   
   public int computeOutcode(float x, float y) {
	   int outcode=0;
	   if(x<xmin) {
     	  if(y<ymin) {
     		  outcode=5; //"0101"
     	  } else if(y>ymax) {
     		  outcode=9; //"1001";
     	  } else { outcode=1; } //"0001";
       }
       else if(x>xmax) {
     	  if(y<ymin) {
     		  outcode=6;  //"0110";
     	  } else if(y>ymax) {
     		  outcode=10;  //"1010";
     	  } else { outcode=2;  }  //"0010";
       }
       else {
     	  if(y<ymin) {
     		  outcode=4;  //"0100";
     	  } else if(y>ymax) {
     		  outcode=8;  //"1000";
     	  } else outcode=0;  //"0000";
       }
	   return outcode;
   }
   
   
   public void dispose(GLAutoDrawable arg0) {
      //method body
   }

   
   public void init(GLAutoDrawable drawable) {
      // method body
	   //4. drive the display() in a loop
	    }
   
   public void reshape(GLAutoDrawable arg0, int arg1, int arg2, int arg3, int arg4) {
      // method body
   }
   //end of main
}//end of class import javax.media.opengl.GL2;