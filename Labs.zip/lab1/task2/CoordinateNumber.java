
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.media.opengl.GL2;
import javax.media.opengl.GLAutoDrawable;
import javax.media.opengl.GLCapabilities;
import javax.media.opengl.GLEventListener;
import javax.media.opengl.GLProfile;
import javax.media.opengl.awt.GLCanvas;
import javax.swing.JFrame;

public class CoordinateNumber implements GLEventListener{
	
	static GLProfile profile = GLProfile.get(GLProfile.GL2);
    static GLCapabilities capabilities = new GLCapabilities(profile);
    // The canvas 
    static GLCanvas glcanvas = new GLCanvas(capabilities);
    
   public static void main(String[] args) {
	      //getting the capabilities object of GL2 profile
	   	  
	      
	   CoordinateNumber l = new CoordinateNumber();
	      //creating frame
	      glcanvas.addGLEventListener(l);
	      glcanvas.setSize(200, 200);
	      
	      final JFrame frame = new JFrame ("straight Line");
	      //adding canvas to frame
	      frame.getContentPane().add(glcanvas);
	      frame.setSize(frame.getContentPane().getPreferredSize());
	      frame.setVisible(true);
	      
	   }
   public void display(GLAutoDrawable drawable) {
      final GL2 gl = drawable.getGL().getGL2();
       	  gl.glBegin (GL2.GL_POINTS);//static field
    	  
       	  String text_file="/Users/User/Desktop/coordinates.txt";
       	  
       	try {
            BufferedReader bf = new BufferedReader(new FileReader(text_file));
            String line = "";
            while((line = bf.readLine()) != null){
                if(!(line.equals("------------"))){
                    float[] array = getCoordinate(line);
                    float horizental = array[0];
                    float vertical = array[1];

                    gl.glVertex2d(horizental,vertical);

                }
                
            }
        } 
        catch (FileNotFoundException ex) {
            Logger.getLogger(CoordinateNumber.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(CoordinateNumber.class.getName()).log(Level.SEVERE, null, ex);
        }
          
        gl.glEnd();
          
      
   }
   
   private float[] getCoordinate(String line) {
	// TODO Auto-generated method stub
	   int n=1;
	   float[] array = new float[2];
       String[] parts = line.split(",");
       for(int i=0;i<n;i++){
    	   array[n] = Float.parseFloat(parts[n]);
       }
       
       return array;
}
public void dispose(GLAutoDrawable arg0) {
      //method body
   }

   
   public void init(GLAutoDrawable drawable) {
      // method body
	   //4. drive the display() in a loop
	    }
   
   public void reshape(GLAutoDrawable arg0, int arg1, int arg2, int arg3, int arg4) {
      // method body
   }
   //end of main
}//end of classimport javax.media.opengl.GL2;