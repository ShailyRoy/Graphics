/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cohen_sutherland_algorithm;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.media.opengl.GL2;
import javax.media.opengl.GLAutoDrawable;
import javax.media.opengl.GLCapabilities;
import javax.media.opengl.GLEventListener;
import javax.media.opengl.GLProfile;
import javax.media.opengl.awt.GLCanvas;
import javax.swing.JFrame;
public class Cohen_Sutherland_Algorithm implements GLEventListener{

    /**
     * @param args the command line arguments
     */
    GL2 gl;
    float X_Max = 0.5f, X_Min = -0.5f, Y_Min = -0.5f, Y_Max = 0.5f; 
    
    static GLProfile profile = GLProfile.get(GLProfile.GL2);
    static GLCapabilities capabilities = new GLCapabilities(profile);
    // The canvas 
    static GLCanvas glcanvas = new GLCanvas(capabilities);
    
    public static void main(String[] args) {
	// TODO code application logic here  
        //getting the capabilities object of GL2 profile
	   	  
	      
	Cohen_Sutherland_Algorithm l = new Cohen_Sutherland_Algorithm();
	//creating frame
	glcanvas.addGLEventListener(l);
	glcanvas.setSize(600, 400);
	      
	final JFrame frame = new JFrame ("straight Line");
	//adding canvas to frame
             
	frame.getContentPane().add(glcanvas);
	frame.setSize(frame.getContentPane().getPreferredSize());
	frame.setVisible(true);
    }
    
    public void display(GLAutoDrawable drawable) {
        gl = drawable.getGL().getGL2();
        
        try {
            //===========================================================================
	    String input_file = new File("").getAbsolutePath()+"\\src\\cohen_sutherland_algorithm\\";
	    input_file = input_file+"Coordinates.txt";
            BufferedWriter bw = new BufferedWriter(new FileWriter(input_file));
            
            float X0_Initial = 0,Y0_Initial = 0,X1_Final = 0,Y1_Final = 0;
            
            String PrintLine = "";
            int NumberOfLines = 1000; //
            for( int i = 0; i < NumberOfLines; i++){
                //get random points
                X0_Initial = getRandom();
                Y0_Initial = getRandom();
                X1_Final = getRandom();
                Y1_Final = getRandom();
                
                PrintLine = X0_Initial+","+Y0_Initial+"   "+X1_Final+","+Y1_Final;
                bw.write(PrintLine);
                if(i < NumberOfLines-1){
                    bw.newLine();
                }
            }
            bw.close();
            
            
            DrawWindow();
            
                
	    BufferedReader br = new BufferedReader(new FileReader(input_file));
	    String GotLine = "";
	    while((GotLine = br.readLine()) != null){
                String[] Point_Parts = GotLine.split("   ");
	        String Initial = Point_Parts[0];
		String Final = Point_Parts[1];
		            
		String[] Initial_Parts = Initial.split(",");
		X0_Initial = Float.parseFloat(Initial_Parts[0]);
		Y0_Initial = Float.parseFloat(Initial_Parts[1]);
		            
		String[] Final_Parts = Final.split(",");
		X1_Final = Float.parseFloat(Final_Parts[0]);
		Y1_Final = Float.parseFloat(Final_Parts[1]);
                        
                //===========================================================================
		//===========================================================================
                
                Cohen_Sutherland(X0_Initial,Y0_Initial,X1_Final,Y1_Final);
                
		            
            }
	}
	                   
         
        catch (FileNotFoundException ex) {
            Logger.getLogger(Cohen_Sutherland_Algorithm.class.getName()).log(Level.SEVERE, null, ex);
        }
        catch (IOException ex) {
            Logger.getLogger(Cohen_Sutherland_Algorithm.class.getName()).log(Level.SEVERE, null, ex);
        }
        
      
    }
   
    public float getRandom() {
        //method body
                  
        Random new_random_number = new Random();
        //formula :: Math.random() * (upper_limit - lower_limit) + lower_limit
        float result = new_random_number.nextFloat() * (1.0f - (-1.0f)) + (-1.0f);
        return result;
    }
    
    public void DrawWindow() {
        
        //Y top
        gl.glBegin (GL2.GL_LINES);//static field
        gl.glColor3f(0f,1f,1f);
        gl.glVertex2d(-1.0f,Y_Max);
        gl.glVertex2d(1.0f,Y_Max);
        gl.glEnd();

        //Y Bottom
        gl.glBegin (GL2.GL_LINES);//static field
        gl.glColor3f(0f,1f,1f);
        gl.glVertex2d(-1.0f,Y_Min);
        gl.glVertex2d(1.0f,Y_Min);
        gl.glEnd();

        //X Left
        gl.glBegin (GL2.GL_LINES);//static field
        gl.glColor3f(0f,1f,1f);
        gl.glVertex2d(X_Min,1.0f);
        gl.glVertex2d(X_Min,-1.0f);
        gl.glEnd();

        //X Right
        gl.glBegin (GL2.GL_LINES);//static field
        gl.glColor3f(0f,1f,1f);
        gl.glVertex2d(X_Max,1.0f);
        gl.glVertex2d(X_Max,-1.0f);
        gl.glEnd();
    }
    
    
    private int MakeCode(float x, float y) {
        int code = 0;
        
        if(y > Y_Max){
            code = code + 8;
        }
        else if(y < Y_Min){
            code = code + 4;
        }
        if(x > X_Max){
            code = code + 2;
        }
        else if(x < X_Min){
            code = code + 1;
        }
        return code;

    }
    
    public void Cohen_Sutherland(float X0_Initial,float Y0_Initial,float X1_Final,float Y1_Final) {
        int Code0 = MakeCode(X0_Initial, Y0_Initial);
        int Code1 = MakeCode(X1_Final, Y1_Final);
        
        int Code = 0;
        
        float x_coordinate = 0.0f, y_coordinate = 0.0f;
                
        while(true){
            if((Code0 | Code1) == 0){
                //Fully Accepted
                gl.glBegin (GL2.GL_LINES);//static field
                gl.glColor3f(0f,1f,0f);   
                gl.glVertex2d(X0_Initial,Y0_Initial);
                gl.glVertex2d(X1_Final,Y1_Final);
                gl.glEnd();
                break;
            }
            else if((Code0 & Code1) != 0){
                //Fully Rejected
                gl.glBegin (GL2.GL_LINES);//static field
                gl.glColor3f(1f,0f,0f);   
                gl.glVertex2d(X0_Initial,Y0_Initial);
                gl.glVertex2d(X1_Final,Y1_Final);
                gl.glEnd();
                break;
            }
               
            else{
                //Partially Accepted
                gl.glBegin (GL2.GL_LINES);//static field
                gl.glColor3f(0f,0f,1f);   
                gl.glVertex2d(X0_Initial,Y0_Initial);
                gl.glVertex2d(X1_Final,Y1_Final);
                gl.glEnd();
            	
                if(Code0 != 0){ 
                    Code = Code0;
                }
                else { 
                    Code = Code1;
                }
                
                if((Code & 8) != 0){
                    y_coordinate = Y_Max;
	            x_coordinate = X0_Initial + (y_coordinate-Y0_Initial) / (Y1_Final-Y0_Initial) * (X1_Final-X0_Initial);
	        }
	        else if((Code & 4) != 0){
                    y_coordinate = Y_Min;
	            x_coordinate = X0_Initial + (y_coordinate-Y0_Initial ) / (Y1_Final-Y0_Initial) * (X1_Final-X0_Initial);
	        }
	        else if((Code & 2) != 0){
                    x_coordinate = X_Max;
	            y_coordinate = Y0_Initial + (x_coordinate-X0_Initial) / (X1_Final-X0_Initial) * (Y1_Final-Y0_Initial);
	        }
	        else if((Code & 1) != 0){
                    x_coordinate = X_Min;
	            y_coordinate = Y0_Initial + (x_coordinate-X0_Initial) / (X1_Final-X0_Initial) * (Y1_Final-Y0_Initial);
	        }
	                   
	        if(Code == Code0){
                    X0_Initial = x_coordinate;
	            Y0_Initial = y_coordinate;
	            Code0 = MakeCode(X0_Initial, Y0_Initial);
	        }
                else{
	            X1_Final = x_coordinate;
	            Y1_Final = y_coordinate;
	            Code1 = MakeCode(X1_Final, Y1_Final);
	        }
            }
        }
    }
    
    public void dispose(GLAutoDrawable arg0) {
       //method body
    }


    public void init(GLAutoDrawable drawable) {
       // method body
            //4. drive the display() in a loop
             }

    public void reshape(GLAutoDrawable arg0, int arg1, int arg2, int arg3, int arg4) {
       // method body
    }
    //end of main
}//end of classimport javax.media.opengl.GL2;

