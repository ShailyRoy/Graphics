import javax.media.opengl.GL2;
import javax.media.opengl.GLAutoDrawable;
import javax.media.opengl.GLCapabilities;
import javax.media.opengl.GLEventListener;
import javax.media.opengl.GLProfile;
import javax.media.opengl.awt.GLCanvas;
import javax.swing.JFrame;

import com.jogamp.opengl.util.Animator;

public class Line implements GLEventListener {

	static GLProfile profile = GLProfile.get(GLProfile.GL2);
	static GLCapabilities capabilities = new GLCapabilities(profile);
	// The canvas

	static GLCanvas glcanvas = new GLCanvas(capabilities);
	static double x1=0,x2=0.5,x3=0.65,x4=0.65,x5=0.5,x6=0,x7=0.15,x8=0.15;
    static double y1=0,y2=0,y3=0.25,y4=0.75,y5=0.5,y6=0.5,y7=0.75,y8=0.25;
    static double theta=0.0, s,c;
	public static void main(String[] args) {
		// getting the capabilities object of GL2 profile

		Line l = new Line();
		// creating frame
		glcanvas.addGLEventListener(l);
		glcanvas.setSize(600, 600);

		final JFrame frame = new JFrame("straight Line");
		// adding canvas to frame
		frame.getContentPane().add(glcanvas);
		frame.setSize(frame.getContentPane().getPreferredSize());
		frame.setVisible(true);
		Animator animator = new Animator(glcanvas);
        //animator.add(canvas);
        animator.start();
	}

	public void display(GLAutoDrawable drawable) {
		update();
        try {
			render(drawable);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	private void update() {
        theta += .1;
        c = Math.cos(Math.toRadians(theta));
        s = Math.sin(Math.toRadians(theta));
    }
	
	
	private void render(GLAutoDrawable drawable) throws InterruptedException {
		final GL2 gl = drawable.getGL().getGL2();
		gl.glClear(GL2.GL_COLOR_BUFFER_BIT);
		// drawing cube
		// outer sq
		/*gl.glBegin(GL2.GL_LINES);
		gl.glColor3f(1,0,0);
		
		gl.glVertex2d(x1,y1);
        gl.glVertex2d(x2,y2);
    
        gl.glVertex2d(x1,y1);
        gl.glVertex2d(x6,y6);

        gl.glVertex2d(x1,y1);
        gl.glVertex2d(x8,y8);

        gl.glVertex2d(x6,y6);
        gl.glVertex2d(x5,y5);
 
        gl.glVertex2d(x5,y5);
        gl.glVertex2d(x2,y2);

        gl.glVertex2d(x8,y8);
        gl.glVertex2d(x3,y3);

        gl.glVertex2d(x3,y3);
        gl.glVertex2d(x2,y2);
  
        gl.glVertex2d(x6,y6);
        gl.glVertex2d(x7,y7);
    
        gl.glVertex2d(x7,y7);
        gl.glVertex2d(x4,y4);

        gl.glVertex2d(x5,y5);
        gl.glVertex2d(x4,y4);

        gl.glVertex2d(x7,y7);
        gl.glVertex2d(x8,y8);
   
        gl.glVertex2d(x4,y4);
        gl.glVertex2d(x3,y3);
		
		gl.glEnd();0.01*/
		//end of cube
		
		
		// drawing rotated cube
		// outer sq
		gl.glBegin(GL2.GL_LINES);
		gl.glColor3f(0,1,0);

		gl.glClear(GL2.GL_COLOR_BUFFER_BIT);
		gl.glVertex2d(x1 * c - y1 * s, x1 * s + y1 * c);
		gl.glVertex2d(x2 * c - y2 * s, x2 * s + y2 * c);

		gl.glVertex2d(x1 * c - y1 * s, x1 * s + y1 * c);
		gl.glVertex2d(x6 * c - y6 * s, x6 * s + y6 * c);

		gl.glVertex2d(x1 * c - y1 * s, x1 * s + y1 * c);
		gl.glVertex2d(x8 * c - y8 * s, x8 * s + y8 * c);

		gl.glVertex2d(x6 * c - y6 * s, x6 * s + y6 * c);
		gl.glVertex2d(x5 * c - y5 * s, x5 * s + y5 * c);

		gl.glVertex2d(x2 * c - y2 * s, x2 * s + y2 * c);
		gl.glVertex2d(x5 * c - y5 * s, x5 * s + y5 * c);

		gl.glVertex2d(x3 * c - y3 * s, x3 * s + y3 * c);
		gl.glVertex2d(x8 * c - y8 * s, x8 * s + y8 * c);

		gl.glVertex2d(x3 * c - y3 * s, x3 * s + y3 * c);
		gl.glVertex2d(x2 * c - y2 * s, x2 * s + y2 * c);

		gl.glVertex2d((x6 * c) - (y6 * s), (x6 * s) + (y6 * c));
		gl.glVertex2d((x7 * c) - (y7 * s), (x7 * s) + (y7 * c));

		gl.glVertex2d(x4 * c - y4 * s, x4 * s + y4 * c);
		gl.glVertex2d(x7 * c - y7 * s, x7 * s + y7 * c);

		gl.glVertex2d(x4 * c - y4 * s, x4 * s + y4 * c);
		gl.glVertex2d(x5 * c - y5 * s, x5 * s + y5 * c);

		gl.glVertex2d(x8 * c - y8 * s, x8 * s + y8 * c);
		gl.glVertex2d(x7 * c - y7 * s, x7 * s + y7 * c);

		gl.glVertex2d(x4 * c - y4 * s, x4 * s + y4 * c);
		gl.glVertex2d(x3 * c - y3 * s, x3 * s + y3 * c);

		gl.glEnd();
		//end of  rotated cube
    }
	
	
	public void dispose(GLAutoDrawable arg0) {
		// method body
	}

	public void init(GLAutoDrawable drawable) {
		// method body
		// 4. drive the display() in a loop
	}

	public void reshape(GLAutoDrawable arg0, int arg1, int arg2, int arg3,
			int arg4) {
		// method body
	}
	// end of main
}// end of classimport javax.media.opengl.GL2;
